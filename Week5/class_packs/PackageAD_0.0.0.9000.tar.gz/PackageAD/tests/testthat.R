library(testthat)
library(PackageAD)

test_check("PackageAD")
