library(testthat)
library(HWPackage)

test_check("HWPackage")
